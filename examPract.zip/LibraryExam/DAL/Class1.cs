﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DAlService
    {
        private LibraryDb data;

        public bool Login(string login, string password)
        {
            var log = data.Acounts.FirstOrDefault(p => p.Login == login && p.Password == password);

            if (log != null)
            {
                return true;
            }
            return false;

        }

        public DAlService()
        {
            data = new LibraryDb();
        }

        public IQueryable<Book> GetSearchBook(string nameBook, string nameGanre)
        {
            return data.Books.Where(p => p.Name == nameBook).Where(g => g.Ganre.Name == nameGanre);
        }
        public IQueryable<Book> GetNewBook()
        {
            return data.Books.OrderByDescending(p => p.YearPublisher).Take(3);

        }
        public IQueryable<Autor> GetTopAutor()
        {
            return data.Autors.OrderByDescending(a => a.Books.Count()).Take(2);
        }

        public IQueryable<Ganre> GetTopGanre()
        {

            return data.Ganres.OrderByDescending(a => a.Books.OrderByDescending(s => s.GanreId).Count()).Take(2);

        }


        public void AddAcount(Acount acount)
        {
            data.Acounts.Add(acount);
            data.SaveChanges();
        }


        public void AddBook(Book objBook)
        {
            data.Books.Add(objBook);
            data.SaveChanges();
        }

        public void DeleteBook(Book objBook)
        {
            data.Books.Remove(objBook);
            data.SaveChanges();
        }

        public void ChengeBook(Book objBook,string name,int page,int year,decimal price,decimal priceSale,bool isCont,int ganreId,int AutorId)
        {
            objBook.Name = name;
            objBook.QuanPages = page;
            objBook.YearPublisher = year;
            objBook.Price = price;
            objBook.PriceToSales = priceSale;
            objBook.isContinuation = isCont;
            objBook.GanreId = ganreId;
            objBook.AutorId = AutorId;
            data.SaveChanges();
        }

        public IQueryable<Book> GetBook()
        {
            return data.Books;
        }
        public List<Ganre> GetNameGanre()
        {
            return data.Ganres.ToList();
        }
        public List<Book> GetNameBook()
        {
            return data.Books.ToList();
        }

    }
}
