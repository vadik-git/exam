﻿namespace DAL
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity;
    using System.Linq;

    public class LibraryDb : DbContext
    {

        public LibraryDb()
            : base("name=LibraryDb")
        {
            Database.SetInitializer(new Initializer());
        }


        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);


            ///Autor
            modelBuilder.Entity<Autor>().Property(p => p.Surname)
                                        .HasMaxLength(100).IsRequired();
            modelBuilder.Entity<Autor>().Property(p => p.Name)
                                       .HasMaxLength(100).IsRequired();
            ///PubHous
            modelBuilder.Entity<PublishingHouse>().Property(p => p.Name)
                                       .HasMaxLength(100).IsRequired();
            ///Ganre
            modelBuilder.Entity<Ganre>().Property(p => p.Name)
                                      .HasMaxLength(100).IsRequired();
            ///Book
            ///
            modelBuilder.Entity<Book>().Property(p => p.Name).HasMaxLength(100).IsRequired();
            modelBuilder.Entity<Book>().Property(p => p.QuanPages).IsRequired();
            modelBuilder.Entity<Book>().Property(p => p.YearPublisher).IsRequired();
            modelBuilder.Entity<Book>().Property(p => p.Price).IsRequired();
            modelBuilder.Entity<Book>().Property(p => p.PriceToSales).IsRequired();
            modelBuilder.Entity<Book>().Property(p => p.isContinuation).IsRequired();

            //one to many
            modelBuilder.Entity<Book>().HasRequired(r => r.Ganre).WithMany(s => s.Books).HasForeignKey(a => a.GanreId).WillCascadeOnDelete(false);
            modelBuilder.Entity<Book>().HasRequired(r => r.Autor).WithMany(s => s.Books).HasForeignKey(a => a.AutorId).WillCascadeOnDelete(false);
            //Many to many
            modelBuilder.Entity<Book>().HasMany(s => s.PublishingHouses).WithMany(o => o.Books);

        }


        public DbSet<Autor> Autors { get; set; }
        public DbSet<Acount> Acounts { get; set; }
        public DbSet<PublishingHouse> PublishingHouses { get; set; }
        public DbSet<Ganre> Ganres { get; set; }
        public DbSet<Book> Books  { get; set; }
    }

    public class Acount
    {
        public int Id  { get; set; }
        [Required]
        [MaxLength(100)]
        public string Login { get; set; }
        [Required]
        [MaxLength(100)]
        public string Password { get; set; }



    }
        
    public class Book
    {

        public Book()
        {
            PublishingHouses = new HashSet<PublishingHouse>();
        }

        public int Id { get; set; }

        public string Name { get; set; }

        public int QuanPages { get; set; }

        public int YearPublisher { get; set; }

        public decimal Price { get; set; }

        public decimal PriceToSales { get; set; }

        public bool isContinuation { get; set; }

        [ForeignKey(nameof(Ganre))]
        public int GanreId { get; set; }

        [ForeignKey(nameof(Autor))]
        public int AutorId { get; set; }

        /////////////////



        public virtual ICollection<PublishingHouse> PublishingHouses { get; set; }
        // // / / / /
        public virtual Ganre Ganre { get; set; }
        public virtual Autor Autor { get; set; }

    }

    public class Autor {

        public int Id { get; set; }

        public string Surname { get; set; }

        public string Name { get; set; }

        public virtual ICollection<Book> Books { get; set; }
    }

    public class PublishingHouse {

        public int Id { get; set; }

        public string Name { get; set; }

        ////
        public virtual ICollection<Book> Books { get; set; }

    }

    public class Ganre
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public virtual ICollection<Book> Books { get; set; }
    }

   




   /* Необходимо хранить следующую информацию о книгах: название книги,
   ФИО автора, название издательства, количество страниц, жанр, год издания,
   себестоимость, цена для продажи, является ли книга продолжением какой-то
   другой книги(например, вторая часть дилогии). */

}