﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    class Initializer : CreateDatabaseIfNotExists<LibraryDb>
    {
        protected override void Seed(LibraryDb context)
        {
            base.Seed(context);


            var acount1 = context.Acounts.Add(new Acount() { Login="Vadim",Password="123321"});
            context.SaveChanges();
            ///Autors
            var autorVadim = context.Autors.Add(new Autor() { Surname = "Slobodzyan", Name = "Vadim" });
            var autorPetro = context.Autors.Add(new Autor() { Surname = "Rayavskiy", Name = "Petro" });
            var autorVasya= context.Autors.Add(new Autor() { Surname = "Bagaverskiy", Name = "Vasya" });
            
            ////ganre
            var ganreDetective = context.Ganres.Add(new Ganre() { Name = "Detective" });
            var ganreRoman = context.Ganres.Add(new Ganre() { Name = "Roman" });
            var ganreComedy = context.Ganres.Add(new Ganre() { Name = "Comedy" });
            ///publisHouse
            var pubHousBETA = context.PublishingHouses.Add(new PublishingHouse() { Name = "BETA" });
            var pubHousIRONIYA = context.PublishingHouses.Add(new PublishingHouse() { Name = "IRONIYA" });
            var pubHousVISNIK = context.PublishingHouses.Add(new PublishingHouse() { Name = "VISNIK" });
            context.SaveChanges();
            ///BOOK

            var b1 = context.Books.Add(new Book()
               {
                Name="Good Boy",
                QuanPages=560,
                YearPublisher=2018,
                Price=2000,
                PriceToSales=2400,
                isContinuation=false,
                GanreId=ganreDetective.Id,
                AutorId=autorVadim.Id
                

                });
            context.SaveChanges();
            b1.PublishingHouses.Add(pubHousBETA);
            context.SaveChanges();


            var b2 = context.Books.Add(new Book()
            {
                Name = "Lazy Man",
                QuanPages = 900,
                YearPublisher = 2020,
                Price = 1300,
                PriceToSales = 1700,
                isContinuation = false,
                GanreId = ganreComedy.Id,
                AutorId = autorPetro.Id


            });
            context.SaveChanges();
            b2.PublishingHouses.Add(pubHousVISNIK);
            context.SaveChanges();

            var b3 = context.Books.Add(new Book()
            {
                Name = "Lovely stories",
                QuanPages = 1000,
                YearPublisher = 2019,
                Price = 1700,
                PriceToSales = 2100,
                isContinuation = false,
                GanreId = ganreRoman.Id,
                AutorId = autorVasya.Id


            });
            context.SaveChanges();
            b3.PublishingHouses.Add(pubHousIRONIYA);

            context.SaveChanges();

        }
    }
}
