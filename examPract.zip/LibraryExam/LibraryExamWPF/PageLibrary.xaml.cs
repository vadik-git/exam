﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DAL;

namespace LibraryExamWPF
{
    /// <summary>
    /// Логика взаимодействия для PageLibrary.xaml
    /// </summary>
    public partial class PageLibrary : Page
    {
        DAlService data = new DAlService();
        ObservableCollection<Book> obBook;

        private void DownGridBook()
        {
            dataGrid.ItemsSource = obBook;
        }
        private void DownbBook()
        {
            obBook = new ObservableCollection<Book>(data.GetBook().ToList());
        }
        private void changeCb()
        {
            comboName.ItemsSource = data.GetNameBook();
            comboName.DisplayMemberPath = nameof(Book.Name);
        }
        public PageLibrary()
        {
            InitializeComponent();


            DownbBook();
            DownGridBook();



            combo.ItemsSource = data.GetNameGanre();
            combo.DisplayMemberPath = nameof(Ganre.Name);
            changeCb();

        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                Book b1 = dataGrid.SelectedItem as Book;
                obBook.Remove(b1);
                data.DeleteBook(b1);
                changeCb();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                SearchBook();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SearchBook()
        {
            dataGrid.ItemsSource = data.GetSearchBook(comboName.Text, combo.Text).Select(f => new {
                Name = f.Name,
                GanreBook = f.Ganre.Name,
                Pages = f.QuanPages,
                Price = f.Price,
                PriceToSale = f.PriceToSales,
                YearPublish = f.YearPublisher

            }).ToList();

            combo.Text = "";
            comboName.Text = "";

        }

        private void BtnBooks_Click(object sender, RoutedEventArgs e)
        {
            DownbBook();
            DownGridBook();
        }



        private void NewTop3Book()
        {
            dataGrid.ItemsSource = data.GetNewBook().Select(f => new {
                NameBook = f.Name,
                Pages = f.QuanPages,
                YearPublish = f.YearPublisher
            }).ToList();
        }

        private void TopAutor()
        {
            dataGrid.ItemsSource = data.GetTopAutor().Select(f => new {

                Name = f.Name,
                Surname = f.Surname,
                CountBooks = f.Books.Count()

            }).ToList();

        }


        private void TopGanre()
        {
            dataGrid.ItemsSource = data.GetTopGanre().Select(f => new {

                NameGanre = f.Name,
                Count = f.Books.Count()

            }).ToList();
        }

        private void BtnAutors_Click(object sender, RoutedEventArgs e)
        {
            TopAutor();
        }

        private void BtnGanres_Click(object sender, RoutedEventArgs e)
        {
            TopGanre();
        }

        private void BtntopBook_Click(object sender, RoutedEventArgs e)
        {
            NewTop3Book();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            Book b1 = dataGrid.SelectedItem as Book;
            FuncTbText(b1);
            
        }

        private void FuncTbText(Book b1)
        {
            tbNameBook.Text = b1.Name;
            tbPageBook.Text = Convert.ToString(b1.QuanPages);
            tbYearPublisher.Text = Convert.ToString(b1.YearPublisher);
            tbPrice.Text = Convert.ToString(b1.Price);
            tbPriceSale.Text = Convert.ToString(b1.PriceToSales);
            tbCont.Text = Convert.ToString(b1.isContinuation);
            tbGanreId.Text = Convert.ToString(b1.GanreId);
            tbAutorId.Text = Convert.ToString(b1.AutorId);
        }
        private void FuncClear()
        {
            tbNameBook.Text ="";
            tbPageBook.Text = "";
            tbYearPublisher.Text="";
            tbPrice.Text ="";
            tbPriceSale.Text ="";
            tbCont.Text ="";
            tbGanreId.Text ="";
            tbAutorId.Text ="";
        }

        private void BtChange_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Book b1 = dataGrid.SelectedItem as Book;
                int page = Convert.ToInt32(tbPageBook.Text);
                int year = Convert.ToInt32(tbYearPublisher.Text);
                decimal priceB = Convert.ToDecimal(tbPrice.Text);
                decimal priceSl = Convert.ToDecimal(tbPriceSale.Text);
                bool isContB = Convert.ToBoolean(tbCont.Text);
                int ganreId = Convert.ToInt32(tbGanreId.Text);
                int autorId = Convert.ToInt32(tbAutorId.Text);
                data.ChengeBook(b1, tbNameBook.Text, page, year, priceB, priceSl, isContB, ganreId, autorId);
                FuncClear();
                changeCb();
                DownbBook();
                DownGridBook();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void BtAdd_Click(object sender, RoutedEventArgs e)
        {
            try { 
            Book newBook = new Book()
            {

                Name = tbNameBook.Text,
                QuanPages = Convert.ToInt32(tbPageBook.Text),
                YearPublisher = Convert.ToInt32(tbYearPublisher.Text),
                Price = Convert.ToDecimal(tbPrice.Text),
                PriceToSales = Convert.ToDecimal(tbPriceSale.Text),
                isContinuation = Convert.ToBoolean(tbCont.Text),
                GanreId = Convert.ToInt32(tbGanreId.Text),
                AutorId = Convert.ToInt32(tbAutorId.Text)
            };
            data.AddBook(newBook);
            FuncClear();
            changeCb();
            DownbBook();
            DownGridBook();
        }
        catch (Exception ex)
        {
                MessageBox.Show(ex.Message);

        }

        }
    }
}
