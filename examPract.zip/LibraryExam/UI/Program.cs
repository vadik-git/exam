﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace UI
{
   
    class Program
    {
        static void Main(string[] args)
        {
            DAlService data = new DAlService();
            foreach(var i in data.GetBook())
            {
                Console.WriteLine(i.Name);
            }


        }
    }
}
