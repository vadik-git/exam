﻿namespace DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddTableSale : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.BookSales",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        BookId = c.Int(nullable: false),
                        AcountId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Acounts", t => t.AcountId, cascadeDelete: true)
                .ForeignKey("dbo.Books", t => t.BookId, cascadeDelete: true)
                .Index(t => t.BookId)
                .Index(t => t.AcountId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.BookSales", "BookId", "dbo.Books");
            DropForeignKey("dbo.BookSales", "AcountId", "dbo.Acounts");
            DropIndex("dbo.BookSales", new[] { "AcountId" });
            DropIndex("dbo.BookSales", new[] { "BookId" });
            DropTable("dbo.BookSales");
        }
    }
}
