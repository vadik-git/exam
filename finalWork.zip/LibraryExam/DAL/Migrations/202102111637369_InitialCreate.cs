﻿namespace DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Acounts",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Login = c.String(nullable: false, maxLength: 100),
                        Password = c.String(nullable: false, maxLength: 100),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Autors",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Surname = c.String(nullable: false, maxLength: 100),
                        Name = c.String(nullable: false, maxLength: 100),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Books",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 100),
                        QuanPages = c.Int(nullable: false),
                        YearPublisher = c.Int(nullable: false),
                        Price = c.Decimal(nullable: false, precision: 18, scale: 2),
                        PriceToSales = c.Decimal(nullable: false, precision: 18, scale: 2),
                        isContinuation = c.Boolean(nullable: false),
                        GanreId = c.Int(nullable: false),
                        AutorId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Autors", t => t.AutorId)
                .ForeignKey("dbo.Ganres", t => t.GanreId)
                .Index(t => t.GanreId)
                .Index(t => t.AutorId);
            
            CreateTable(
                "dbo.Ganres",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 100),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.PublishingHouses",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 100),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.BookPublishingHouses",
                c => new
                    {
                        Book_Id = c.Int(nullable: false),
                        PublishingHouse_Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Book_Id, t.PublishingHouse_Id })
                .ForeignKey("dbo.Books", t => t.Book_Id, cascadeDelete: true)
                .ForeignKey("dbo.PublishingHouses", t => t.PublishingHouse_Id, cascadeDelete: true)
                .Index(t => t.Book_Id)
                .Index(t => t.PublishingHouse_Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.BookPublishingHouses", "PublishingHouse_Id", "dbo.PublishingHouses");
            DropForeignKey("dbo.BookPublishingHouses", "Book_Id", "dbo.Books");
            DropForeignKey("dbo.Books", "GanreId", "dbo.Ganres");
            DropForeignKey("dbo.Books", "AutorId", "dbo.Autors");
            DropIndex("dbo.BookPublishingHouses", new[] { "PublishingHouse_Id" });
            DropIndex("dbo.BookPublishingHouses", new[] { "Book_Id" });
            DropIndex("dbo.Books", new[] { "AutorId" });
            DropIndex("dbo.Books", new[] { "GanreId" });
            DropTable("dbo.BookPublishingHouses");
            DropTable("dbo.PublishingHouses");
            DropTable("dbo.Ganres");
            DropTable("dbo.Books");
            DropTable("dbo.Autors");
            DropTable("dbo.Acounts");
        }
    }
}
